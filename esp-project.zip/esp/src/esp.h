// Data acquisition + projection. No rendering here.
#pragma once
#include "il2.h"
#include "offsets.h"
#include <cmath>
#include <cstdio>
#include <string>
#include <vector>

namespace esp {

struct Vec3 { float x = 0, y = 0, z = 0; };
struct Quat { float x = 0, y = 0, z = 0, w = 1; };
struct Vec2 { float x = 0, y = 0; };

inline Vec3 operator-(Vec3 a, Vec3 b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
inline Vec3 operator+(Vec3 a, Vec3 b) { return {a.x + b.x, a.y + b.y, a.z + b.z}; }
inline Vec3 cross(Vec3 a, Vec3 b) { return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x}; }
inline Vec3 rotate(Quat q, Vec3 v) {
    Vec3 u{q.x, q.y, q.z};
    Vec3 t = cross(u, v); t = {t.x + q.w * v.x, t.y + q.w * v.y, t.z + q.w * v.z};
    Vec3 r = cross(u, t);
    return {v.x + 2 * r.x, v.y + 2 * r.y, v.z + 2 * r.z};
}
inline Quat conj(Quat q) { return {-q.x, -q.y, -q.z, q.w}; }
inline Quat mul(Quat a, Quat b) {
    return {a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y, a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x,
            a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w, a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z};
}
inline bool finite3(Vec3 v) { return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z) && std::fabs(v.x) < 1e5f && std::fabs(v.y) < 1e5f && std::fabs(v.z) < 1e5f; }

// ---- Native Transform world read -------------------------------------------------------------
// Layout is Unity-version dependent. These are CANDIDATE values (INFERRED, not OBSERVED for this build).
// Validation: quaternion norm ~1, finite position, bounded parent chain, and the cross-check in Collector (pivot vs networkPosition).
// FILL: if the cross-check fails, dump the native Transform of the managed pointer shown in the status line and re-derive.
namespace tf {
constexpr uint32_t T_HIER = 0x38, T_INDEX = 0x40;     // native Transform -> TransformHierarchy*, index
constexpr uint32_t H_MATRICES = 0x18, H_INDICES = 0x20;
constexpr uint32_t STRIDE = 0x30;                     // TRS: t(vec4) q(vec4) s(vec4)
}

inline bool transform_world(uint64_t managed, Vec3& pos, Quat& rot) {
    uint64_t nat, hier, mats, idxs;
    int32_t idx;
    if (!il2::ptr(managed + il2::UOBJ_CACHED, nat) || !il2::ptr(nat + tf::T_HIER, hier) || !mem::rd(nat + tf::T_INDEX, idx)) return false;
    if (idx < 0 || idx > 100000 || !il2::ptr(hier + tf::H_MATRICES, mats) || !il2::ptr(hier + tf::H_INDICES, idxs)) return false;
    struct TRS { float t[4], q[4], s[4]; } m;
    if (!mem::rd(mats + (uint64_t)idx * tf::STRIDE, m)) return false;
    Vec3 p{m.t[0], m.t[1], m.t[2]};
    Quat q{m.q[0], m.q[1], m.q[2], m.q[3]};
    int32_t cur;
    if (!mem::rd(idxs + (uint64_t)idx * 4, cur)) return false;
    for (int depth = 0; cur >= 0; depth++) {
        if (depth > 64 || cur > 100000) return false;
        TRS pm;
        if (!mem::rd(mats + (uint64_t)cur * tf::STRIDE, pm)) return false;
        p = rotate(Quat{pm.q[0], pm.q[1], pm.q[2], pm.q[3]}, Vec3{p.x * pm.s[0], p.y * pm.s[1], p.z * pm.s[2]}) + Vec3{pm.t[0], pm.t[1], pm.t[2]};
        q = mul(Quat{pm.q[0], pm.q[1], pm.q[2], pm.q[3]}, q);
        if (!mem::rd(idxs + (uint64_t)cur * 4, cur)) return false;
    }
    float n = q.x * q.x + q.y * q.y + q.z * q.z + q.w * q.w;
    if (!finite3(p) || std::fabs(n - 1.f) > 0.02f) return false;
    pos = p; rot = q;
    return true;
}

// ---- Class / static resolution without script.json ---------------------------------------------
// PlayerController::GetView(int) is a static method that touches _actorToView, so its machine code loads the
// PlayerController Il2CppClass* through ADRP+LDR. We decode those instructions from the live process and accept
// a candidate only if the pointed class is named "PlayerController". Nothing here is trusted without that check.
inline bool find_class_via_code(uint64_t code_va, const char* want, uint64_t& klass_out) {
    uint32_t ins[160];
    if (!mem::read(code_va, ins, sizeof ins)) return false;
    uint64_t page[32] = {};
    for (int i = 0; i < 160; i++) {
        uint32_t w = ins[i];
        uint64_t pc = code_va + (uint64_t)i * 4;
        if ((w & 0x9F000000u) == 0x90000000u) {                                   // ADRP
            int64_t imm = (int64_t)((((w >> 5) & 0x7FFFF) << 2) | ((w >> 29) & 3));
            if (imm & (1 << 20)) imm -= (1 << 21);
            page[w & 31] = (pc & ~0xFFFull) + (uint64_t)(imm << 12);
        } else if ((w & 0xFFC00000u) == 0xF9400000u) {                            // LDR Xt,[Xn,#imm12*8]
            uint32_t rn = (w >> 5) & 31;
            if (!page[rn]) continue;
            uint64_t g = page[rn] + (uint64_t)((w >> 10) & 0xFFF) * 8, k;
            std::string n;
            if (il2::ptr(g, k) && il2::klass_name(k, n) && n == want) { klass_out = k; return true; }
        }
    }
    return false;
}

// ---- Frame collection --------------------------------------------------------------------------
struct PlayerInfo { Vec3 pos; std::string name; };
struct Frame {
    bool cam_ok = false;
    Vec3 cam_pos; Quat cam_rot;
    std::vector<PlayerInfo> others;
    std::string status;
};

class Collector {
public:
    explicit Collector(uint64_t base) : base_(base) {}

    void collect(Frame& f) {
        f = Frame{};
        if (!klass_ && !find_class_via_code(base_ + off::PlayerController::RVA_GetView, "PlayerController", klass_)) {
            f.status = "UNRESOLVED: PlayerController class (ADRP/LDR scan of GetView failed; check build/base)";
            return;
        }
        uint64_t dict = 0;
        if (!static_dict(dict)) { f.status = "WAIT: _actorToView not initialised (join a match)"; return; }
        std::vector<il2::DictEntry> ents;
        if (!il2::dict_int_ref(dict, ents)) { f.status = "FAIL: Dictionary entries layout mismatch"; return; }

        int views = 0, nets = 0, tf_checked = 0, tf_ok = 0;
        for (auto& e : ents) {
            if (!il2::is_a(e.value, "PhotonView")) continue;
            views++;
            uint64_t lst, net = 0;
            std::vector<uint64_t> comps;
            if (!il2::ptr(e.value + off::PhotonView::ObservedComponents, lst) || !il2::list_refs(lst, comps)) continue;
            for (uint64_t c : comps) if (il2::is_a(c, "PlayerNetwork")) { net = c; break; }
            if (!net) continue;
            nets++;
            uint8_t mine = 0;
            if (!mem::rd(e.value + off::PhotonView::_IsMine_k__BackingField, mine)) continue;

            if (mine) {
                uint64_t camT;
                if (il2::ptr(net + off::PlayerNetwork::_mainCamera, camT) && transform_world(camT, f.cam_pos, f.cam_rot)) f.cam_ok = true;
                continue;
            }
            uint8_t first = 0;
            if (!mem::rd(net + off::PlayerNetwork::_hasReceivedFirstSnapshot, first) || !first) continue;
            PlayerInfo p;
            if (!mem::rd(net + off::PlayerNetwork::networkPosition, p.pos) || !finite3(p.pos)) continue;

            // Independent sample for the native Transform layout: remote camera pivot must sit above networkPosition.
            uint64_t pivot; Vec3 pp; Quat pq;
            if (il2::ptr(net + off::PlayerNetwork::_remoteCameraPivot, pivot)) {
                tf_checked++;
                if (transform_world(pivot, pp, pq) && std::hypot(pp.x - p.pos.x, pp.z - p.pos.z) < 1.5f && std::fabs(pp.y - p.pos.y) < 3.f) tf_ok++;
            }
            uint64_t owner, ns;
            p.name = "?";
            if (il2::ptr(e.value + off::PhotonView::_Owner_k__BackingField, owner) && il2::ptr(owner + off::Player::nickName, ns)) il2::read_string(ns, p.name);
            f.others.push_back(p);
        }
        char buf[160];
        snprintf(buf, sizeof buf, "views=%d nets=%d others=%zu cam=%s tfcheck=%d/%d", views, nets, f.others.size(), f.cam_ok ? "ok" : "NO", tf_ok, tf_checked);
        f.status = buf;
    }

private:
    bool static_dict(uint64_t& dict) {
        for (uint32_t o : {sf_off_, 0xB8u, 0xA8u, 0xB0u, 0xC0u, 0xC8u, 0xD0u}) {
            if (!o) continue;
            uint64_t sf, d;
            if (!il2::ptr(klass_ + o, sf) || !il2::ptr(sf + off::PlayerController::STATIC__actorToView, d)) continue;
            if (il2::is_a(d, "Dictionary`2")) { sf_off_ = o; dict = d; return true; }
        }
        return false;
    }
    uint64_t base_, klass_ = 0;
    uint32_t sf_off_ = 0;
};

// ---- Projection ---------------------------------------------------------------------------------
// Unity camera space: +X right, +Y up, +Z forward (left-handed). pc = conj(q) * (p - camPos).
// Screen origin top-left. fov is vertical unless fov_is_horizontal.
struct Projector {
    Vec3 pos; Quat rot; float fov_deg = 60.f; bool fov_horizontal = false; float W = 1920, H = 1080;
    bool project(Vec3 p, Vec2& out) const {
        Vec3 c = rotate(conj(rot), p - pos);
        if (c.z < 0.05f) return false;
        float aspect = W / H, half = fov_deg * 0.5f * 3.14159265f / 180.f;
        float ty = fov_horizontal ? std::tan(half) / aspect : std::tan(half);
        out.x = (c.x / (c.z * ty * aspect) * 0.5f + 0.5f) * W;
        out.y = (0.5f - c.y / (c.z * ty) * 0.5f) * H;
        return true;
    }
};

}  // namespace esp
