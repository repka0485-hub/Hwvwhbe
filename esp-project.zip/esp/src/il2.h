// IL2CPP / managed-heap helpers. Every layout assumption here is validated at runtime by name checks (see resolver.h).
#pragma once
#include "mem.h"
#include <vector>

namespace il2 {

constexpr uint32_t K_NAME = 0x10;       // Il2CppClass::name        (metadata v24+, 64-bit) - validated by class_name()
constexpr uint32_t ARR_LEN = 0x18;      // Il2CppArray::max_length
constexpr uint32_t ARR_DATA = 0x20;     // Il2CppArray::vector
constexpr uint32_t UOBJ_CACHED = 0x10;  // UnityEngine.Object::m_CachedPtr (OBSERVED in dump.cs)

inline bool ptr(uint64_t a, uint64_t& out) { return mem::rd(a, out) && out > 0x10000 && (out >> 47) == 0; }

inline bool klass_name(uint64_t klass, std::string& name) {
    uint64_t np;
    return ptr(klass + K_NAME, np) && mem::read_cstr(np, name, 96) && !name.empty();
}
inline bool obj_class_name(uint64_t obj, std::string& name) {
    uint64_t k;
    return ptr(obj, k) && klass_name(k, name);
}
inline bool is_a(uint64_t obj, const char* want) {
    std::string n; return obj_class_name(obj, n) && n == want;
}

inline bool read_string(uint64_t strobj, std::string& out) {   // Il2CppString: len@0x10, UTF-16@0x14
    int32_t len; out.clear();
    if (!mem::rd(strobj + 0x10, len) || len < 0 || len > 64) return false;
    std::vector<uint16_t> w(len);
    if (len && !mem::read(strobj + 0x14, w.data(), len * 2)) return false;
    for (uint16_t c : w) out.push_back(c < 0x80 ? static_cast<char>(c) : '?');
    return true;
}

// List<T> of reference types: _items@0x10, _size@0x18 (standard corlib layout, validated by array class name).
inline bool list_refs(uint64_t list, std::vector<uint64_t>& out, int32_t cap = 64) {
    uint64_t items; int32_t size; out.clear();
    if (!ptr(list + 0x10, items) || !mem::rd(list + 0x18, size) || size < 0 || size > cap) return false;
    out.resize(size);
    return size == 0 || mem::read(items + ARR_DATA, out.data(), size * 8);
}

// Dictionary<int, ref> (.NET Core style, as indicated by _buckets/_entries in dump.cs).
// The entries array is located by its class name "Entry[]" instead of a hard-coded field offset.
// Entry<int,ref>: hash@0 next@4 key@8 value@0x10, stride 0x18 (INFERRED, validated by caller through value class names).
struct DictEntry { int32_t key; uint64_t value; };
inline bool dict_int_ref(uint64_t dict, std::vector<DictEntry>& out, int32_t cap = 256) {
    out.clear();
    for (uint32_t o = 0x10; o <= 0x30; o += 8) {
        uint64_t arr;
        if (!ptr(dict + o, arr)) continue;
        std::string n;
        if (!obj_class_name(arr, n) || n != "Entry[]") continue;
        uint64_t len; if (!mem::rd(arr + ARR_LEN, len) || len == 0 || len > 4096) return false;
        if (len > static_cast<uint64_t>(cap)) len = cap;
        std::vector<uint8_t> raw(len * 0x18);
        if (!mem::read(arr + ARR_DATA, raw.data(), raw.size())) return false;
        for (uint64_t i = 0; i < len; i++) {
            const uint8_t* e = raw.data() + i * 0x18;
            int32_t next; memcpy(&next, e + 4, 4);
            if (next < -1) continue;                         // free slot
            DictEntry d; memcpy(&d.key, e + 8, 4); memcpy(&d.value, e + 0x10, 8);
            if (d.value > 0x10000) out.push_back(d);
        }
        return true;
    }
    return false;
}

}  // namespace il2
