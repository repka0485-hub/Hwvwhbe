// Remote process memory access (root required). All reads are checked; callers must test the result.
#pragma once
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <dirent.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <sys/uio.h>

namespace mem {

inline pid_t g_pid = 0;
inline int g_memfd = -1;

inline bool read(uint64_t addr, void* out, size_t n) {
    if (!g_pid || addr < 0x10000 || (addr >> 47) != 0) return false;
    iovec l{out, n}, r{reinterpret_cast<void*>(addr), n};
    ssize_t got = syscall(SYS_process_vm_readv, g_pid, &l, 1, &r, 1, 0);
    if (got == static_cast<ssize_t>(n)) return true;
    if (g_memfd >= 0) return pread64(g_memfd, out, n, static_cast<off64_t>(addr)) == static_cast<ssize_t>(n);
    return false;
}
template <class T> inline bool rd(uint64_t a, T& v) { return read(a, &v, sizeof(T)); }

// Reads a NUL-terminated string in small chunks so a string at the end of a mapping does not fail the whole read.
inline bool read_cstr(uint64_t addr, std::string& out, size_t max = 128) {
    out.clear();
    char buf[16];
    while (out.size() < max) {
        size_t n = 16 - (addr & 15);                 // never cross a 16-byte boundary
        if (!read(addr, buf, n)) return !out.empty() ? false : false;
        for (size_t i = 0; i < n; i++) { if (!buf[i]) return true; out.push_back(buf[i]); }
        addr += n;
    }
    return false;                                    // no terminator within max
}

struct Target { pid_t pid = 0; uint64_t base = 0; std::string cmd; };

// Finds a process that maps libil2cpp.so. `pkg` (optional) must equal the process cmdline.
// base = start - file_offset of the lowest mapping. If the library is mapped straight out of the APK
// (extractNativeLibs=false) this is NOT the ELF load base; the resolver's name checks will fail in that case.
inline bool find_target(const std::string& pkg, Target& t) {
    DIR* d = opendir("/proc");
    if (!d) return false;
    bool ok = false;
    while (dirent* e = readdir(d)) {
        char* end; long pid = strtol(e->d_name, &end, 10);
        if (*end || pid <= 1) continue;
        char path[64]; snprintf(path, sizeof path, "/proc/%ld/cmdline", pid);
        char cmd[256] = {}; FILE* f = fopen(path, "r"); if (!f) continue;
        size_t n = fread(cmd, 1, sizeof cmd - 1, f); fclose(f); (void)n;
        if (!pkg.empty() ? pkg != cmd : strchr(cmd, ':') != nullptr) continue;
        snprintf(path, sizeof path, "/proc/%ld/maps", pid);
        f = fopen(path, "r"); if (!f) continue;
        char line[512]; uint64_t base = 0;
        while (fgets(line, sizeof line, f)) {
            if (!strstr(line, "libil2cpp.so")) continue;
            unsigned long long s, en, off;
            if (sscanf(line, "%llx-%llx %*4s %llx", &s, &en, &off) == 3) { base = s - off; break; }
        }
        fclose(f);
        if (base) { t.pid = static_cast<pid_t>(pid); t.base = base; t.cmd = cmd; ok = true; break; }
    }
    closedir(d);
    return ok;
}

inline bool attach(const Target& t) {
    g_pid = t.pid;
    if (g_memfd >= 0) close(g_memfd);
    char p[64]; snprintf(p, sizeof p, "/proc/%d/mem", t.pid);
    g_memfd = open(p, O_RDONLY);
    return true;
}

}  // namespace mem
