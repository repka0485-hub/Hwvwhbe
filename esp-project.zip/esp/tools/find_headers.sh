#!/bin/sh
# Discovers the AndroidImgui header names (they are not documented in its README) and writes ai_includes.h.
# usage: find_headers.sh <AndroidImgui checkout> <output ai_includes.h>
set -e
R="$1"; OUT="$2"
find_hdr() { grep -rlE "$1" "$R/src" "$R/test" --include='*.h' --include='*.hpp' 2>/dev/null | head -1; }
H1=$(find_hdr 'class[[:space:]]+ANativeWindowCreator')
H2=$(find_hdr 'class[[:space:]]+GraphicsManager|struct[[:space:]]+GraphicsManager')
H3=$(find_hdr 'namespace[[:space:]]+Touch')
H4=$(find_hdr 'Android_LoadSystemFont')
for v in H1 H2 H3; do eval "x=\$$v"; [ -n "$x" ] || { echo "header for $v not found in $R"; exit 1; }; done
{
  echo "// generated"
  echo "#pragma once"
  for h in "$H1" "$H2" "$H3" "$H4"; do [ -n "$h" ] && echo "#include \"$(basename "$h")\""; done
  echo "#include \"imgui.h\""
} > "$OUT"
# directories that must be on the include path (src is already PUBLIC in the library; test/ holds the touch helper)
dirname "$H3" > "$OUT.dirs"
cat "$OUT"
